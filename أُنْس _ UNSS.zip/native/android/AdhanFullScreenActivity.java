package com.anis.unss;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.widget.FrameLayout;
import java.util.Calendar;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AdhanFullScreenActivity extends Activity {
    private int notificationId;
    private TextView clockView, dateView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() { @Override public void run() { updateClock(); handler.postDelayed(this, 1000); } };
    private final int gold = Color.rgb(239, 207, 132);
    private final int pale = Color.rgb(222, 237, 255);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.rgb(5, 18, 54));
        getWindow().setNavigationBarColor(Color.rgb(5, 18, 54));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        notificationId = getIntent().getIntExtra("notificationId", 0);
        String prayer = getIntent().getStringExtra("prayer");
        if (prayer == null || prayer.trim().isEmpty()) prayer = "الصلاة";

        FrameLayout frame = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5, 18, 54), Color.rgb(15, 61, 135), Color.rgb(5, 23, 67)});
        frame.setBackground(bg);
        frame.addView(new CirclesView(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(26), dp(48), dp(26), dp(28));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        clockView = new TextView(this);
        clockView.setTextColor(Color.WHITE); clockView.setTextSize(68);
        clockView.setTypeface(Typeface.create("serif", Typeface.BOLD));
        clockView.setGravity(Gravity.CENTER); clockView.setTextDirection(View.TEXT_DIRECTION_LTR);
        clockView.setShadowLayer(dp(10), 0, 0, Color.argb(120, 239, 207, 132));
        root.addView(clockView, new LinearLayout.LayoutParams(-1, -2));

        dateView = new TextView(this);
        dateView.setTextColor(pale); dateView.setTextSize(19);
        dateView.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        dateView.setGravity(Gravity.CENTER); dateView.setTextDirection(View.TEXT_DIRECTION_RTL);
        LinearLayout.LayoutParams dateLp = new LinearLayout.LayoutParams(-1, -2);
        dateLp.topMargin = dp(4); dateLp.bottomMargin = dp(14); root.addView(dateView, dateLp);
        updateClock();

        TextView brand = new TextView(this);
        brand.setText("أُنْس  |  UNSS");
        brand.setTextColor(gold); brand.setTextSize(23);
        brand.setTypeface(Typeface.create("serif", Typeface.BOLD));
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(-1, -2);
        brandLp.topMargin = dp(4); brandLp.bottomMargin = dp(16);
        root.addView(brand, brandLp);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable logoFrame = new GradientDrawable();
        logoFrame.setShape(GradientDrawable.OVAL); logoFrame.setColor(Color.WHITE);
        logoFrame.setStroke(dp(2), gold);
        logo.setBackground(logoFrame); logo.setPadding(dp(10), dp(10), dp(10), dp(10));
        logo.setElevation(dp(8));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(104), dp(104));
        logoLp.bottomMargin = dp(22); root.addView(logo, logoLp);

        TextView title = new TextView(this);
        title.setText("حان موعد صلاة " + prayer);
        title.setTextColor(Color.WHITE); title.setTextSize(30);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setGravity(Gravity.CENTER); title.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("حيَّ على الصلاة"); sub.setTextColor(pale); sub.setTextSize(23);
        sub.setTypeface(Typeface.create("serif", Typeface.NORMAL)); sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(12); subLp.bottomMargin = dp(24); root.addView(sub, subLp);

        LinearLayout divider = new LinearLayout(this);
        GradientDrawable line = new GradientDrawable(); line.setColor(gold); line.setCornerRadius(dp(2));
        divider.setBackground(line);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(dp(74), dp(3));
        lineLp.bottomMargin = dp(20); root.addView(divider, lineLp);

        TextView reminder = new TextView(this);
        reminder.setText("استعد للصلاة، جعلها الله راحةً لقلبك");
        reminder.setTextColor(pale); reminder.setTextSize(17);
        reminder.setGravity(Gravity.CENTER); reminder.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(reminder, new LinearLayout.LayoutParams(-1, -2));

        View spacer = new View(this); root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        FrameLayout closeWrap = new FrameLayout(this);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL); ring.setColor(Color.argb(40, 255, 255, 255));
        ring.setStroke(dp(3), Color.argb(110, 239, 207, 132));
        closeWrap.setBackground(ring);
        View close = new View(this) {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                p.setColor(Color.rgb(30, 90, 224)); p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(3)); p.setStrokeCap(Paint.Cap.ROUND);
                float w = getWidth(), h = getHeight(), m = w * 0.32f;
                c.drawLine(m, m, w - m, h - m, p); c.drawLine(w - m, m, m, h - m, p);
            }
        };
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.OVAL); btnBg.setColor(Color.rgb(246, 248, 252));
        close.setBackground(btnBg); close.setElevation(dp(8));
        close.setContentDescription("إغلاق");
        closeWrap.addView(close, new FrameLayout.LayoutParams(dp(78), dp(78), Gravity.CENTER));
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(94), dp(94));
        closeLp.bottomMargin = dp(18); root.addView(closeWrap, closeLp);
        closeWrap.setOnClickListener(v -> closeScreen());
        close.setOnClickListener(v -> closeScreen());

        setContentView(frame);
    }

    private static final String[] DAYS = {"الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"};
    private static final String[] MONTHS = {"يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"};
    private static String ar(String in) {
        StringBuilder sb = new StringBuilder();
        for (char ch : in.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char)('\u0660' + (ch - '0')) : ch);
        return sb.toString();
    }
    private void updateClock() {
        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR); if (h == 0) h = 12;
        clockView.setText(ar(h + ":" + String.format(java.util.Locale.US, "%02d", c.get(Calendar.MINUTE))));
        dateView.setText(ar(DAYS[c.get(Calendar.DAY_OF_WEEK) - 1] + "، " + c.get(Calendar.DAY_OF_MONTH) + " " + MONTHS[c.get(Calendar.MONTH)]));
    }
    @Override protected void onResume() { super.onResume(); handler.post(ticker); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(ticker); }

    private class CirclesView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        CirclesView(Context c) { super(c); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(22, 255, 255, 255)); c.drawCircle(w * 0.95f, h * 0.30f, w * 0.95f, p);
            p.setColor(Color.argb(16, 239, 207, 132)); c.drawCircle(w * 0.05f, h * 0.88f, w * 0.85f, p);
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void closeScreen() {
        try { if (notificationId != 0) ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(notificationId); } catch (Exception ignored) {}
        finish();
    }
    @Override public void onBackPressed() { closeScreen(); }
    @Override protected void onDestroy() { handler.removeCallbacks(ticker); super.onDestroy(); }
}
